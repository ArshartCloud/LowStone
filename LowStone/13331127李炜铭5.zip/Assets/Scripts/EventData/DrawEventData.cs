﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DrawEventData {
    public Player player;
    public Card card;
}
