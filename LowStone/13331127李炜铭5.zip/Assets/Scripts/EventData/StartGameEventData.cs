﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartGameEventData {
    public Player currentPlayer;
    public Player enemy;
    
}
