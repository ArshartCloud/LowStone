﻿using System.Collections;
using System.Collections.Generic;

public class Battlefield:Zone
{

    public Battlefield()
    {
        m_maxSize = 7;
    }
}
