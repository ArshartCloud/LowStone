﻿using System.Collections;
using System.Collections.Generic;

public class Hand :Zone {
    public Hand()
    {
        m_maxSize = 10;
    }
}
