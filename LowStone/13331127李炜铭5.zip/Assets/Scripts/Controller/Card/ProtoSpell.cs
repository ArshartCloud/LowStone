﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProtoSpell : ProtoCard
{

    // properties
    public List<Operation> Effect
    {
        get { return m_effect; }
    }

    // variables
    private List<Operation> m_effect;

    // constructors

    // methods

}
