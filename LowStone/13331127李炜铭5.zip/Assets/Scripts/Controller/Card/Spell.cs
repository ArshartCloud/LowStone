﻿//using System;

//public class Spell : Card {
//	// constructors
//	public Spell(SpellPrototype prototype) : base(prototype) {
//	}

//}
