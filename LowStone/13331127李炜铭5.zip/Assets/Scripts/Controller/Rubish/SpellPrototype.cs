﻿//using System;

//public class SpellPrototype : CardPrototype {
//	// constructors
//	public SpellPrototype(int cost) : base(cost) {
//	}

//	// methods
//	public override Card CreateCard() {
//		return CreateSpell();
//	}

//	public Spell CreateSpell() {
//		return new Spell(this);
//	}

//}
