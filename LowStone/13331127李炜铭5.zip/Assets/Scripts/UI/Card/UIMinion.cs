﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Lowstone.UI
{
    public class UIMinion : UICard
    {
        protected UICardShape shape = UICardShape.Minion;
    }
}